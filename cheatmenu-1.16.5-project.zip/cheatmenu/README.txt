ЧИТ-МЕНЮ для Minecraft 1.16.5 (Fabric). Только одиночная игра.

СБОРКА (любой из способов):
1) Windows: поставь JDK 17 + Gradle 7.3.3, запусти build.bat
2) Linux/Mac: ./build.sh
3) Без установки: залей папку на GitHub (новый репозиторий) ->
   вкладка Actions -> build -> Artifacts -> cheatmenu-jar.

Готовый jar: build/libs/cheatmenu-1.0.0.jar (не *-sources.jar).
Положи его в .minecraft/mods вместе с Fabric API 0.42.0+1.16.
Меню: Правый Shift.
