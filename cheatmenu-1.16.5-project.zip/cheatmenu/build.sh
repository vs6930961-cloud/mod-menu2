#!/bin/sh
command -v gradle >/dev/null || { echo "Install JDK 17 and Gradle 7.3.3 first"; exit 1; }
gradle wrapper --gradle-version 7.3.3 && ./gradlew build && echo "Done: build/libs/cheatmenu-1.0.0.jar"
