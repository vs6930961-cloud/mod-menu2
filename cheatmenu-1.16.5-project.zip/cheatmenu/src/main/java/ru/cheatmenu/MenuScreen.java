package ru.cheatmenu;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.GameMode;

public class MenuScreen extends Screen {
    static int tab = 0, amount = 64;
    static String query = "";
    static final String[] TABS = {"Движение", "Бой", "Ресурсы", "Мир", "КС", "Оптимизация", "Инструкция"};
    static final String[] KITS = {"Алмазы x64", "Незерит x16", "Зол. яблоки x16", "Зачар. яблоки x8",
            "Жемчуг Края x16", "Стейки x64", "Булыжник x64", "TNT x32", "Элитры + фейерв.",
            "Алмазный набор", "Незерит. набор", "+30 уровней"};
    static final String[] HELP = {
            "§eОткрыть меню: Правый Shift (меняется в Управлении).",
            "§cЧиты работают ТОЛЬКО в одиночной игре.",
            "§7На серверах и в LAN они сами отключаются.",
            "",
            "§aПолёт§f: включи, в игре дважды нажми Пробел.",
            "§aWH§f: подсветка существ и предметов сквозь стены.",
            "§aАим§f: наводит камеру на ближайшую цель (по умолч. пока",
            "  зажата ЛКМ). Угол, дальность, плавность — вкладка «Бой».",
            "§aБанихоп§f: держи Пробел + W — прыжки без задержки.",
            "§aСтрейфы§f: в прыжке держи W + A/D и плавно поворачивай",
            "  мышь в ту же сторону — скорость растёт.",
            "§aРесурсы§f: пиши название предмета по-русски и жми на него.",
            "§aМир§f: лечение, время, погода, режим игры, яркость.",
            "§aКС§f: «Построить карту», потом «Старт». B — магазин.",
            "  Убей всех T-ботов за 2 мин. Убийство $300, победа $3250.",
            "  Матч до 8 побед. Закупка 15 сек в начале раунда.",
            "§aОптимизация§f: пресеты FPS + советы по модам."
    };

    private final List<ButtonWidget> res = new ArrayList<ButtonWidget>();
    private TextFieldWidget search;

    public MenuScreen() { super(new LiteralText("Чит-меню")); }

    private boolean ok() { return Features.allowed(client); }

    @Override
    protected void init() {
        res.clear();
        search = null;
        for (int i = 0; i < TABS.length; i++) {
            final int t = i;
            addButton(new ButtonWidget(8, 28 + i * 24, 100, 20,
                    new LiteralText((tab == i ? "§e> " : "") + TABS[i]),
                    b -> { tab = t; init(client, width, height); }));
        }
        if (!ok() && tab != 5 && tab != 6) return;

        final int x = 118, y = 28, w = 150, x2 = x + w + 8;
        switch (tab) {
            case 0:
                tog(x, y, w, "Полёт в выживании", () -> Cfg.fly, v -> Cfg.fly = v);
                cyc(x2, y, w, "Скорость полёта", new float[]{1, 2, 4, 8}, () -> Cfg.flySpeed, v -> Cfg.flySpeed = v);
                tog(x, y + 24, w, "Банихоп", () -> Cfg.bhop, v -> Cfg.bhop = v);
                cyc(x2, y + 24, w, "Макс. скорость", new float[]{0.4f, 0.6f, 0.8f, 1.2f}, () -> Cfg.maxSpeed, v -> Cfg.maxSpeed = v);
                tog(x, y + 48, w, "Стрейфы", () -> Cfg.strafe, v -> Cfg.strafe = v);
                cyc(x2, y + 48, w, "Сила стрейфа", new float[]{0.5f, 1, 2, 3}, () -> Cfg.strafePower, v -> Cfg.strafePower = v);
                break;
            case 1:
                tog(x, y, w, "WH", () -> Cfg.wh, v -> Cfg.wh = v);
                tog(x, y + 24, w, "WH: игроки", () -> Cfg.whPlayers, v -> Cfg.whPlayers = v);
                tog(x, y + 48, w, "WH: мобы", () -> Cfg.whMobs, v -> Cfg.whMobs = v);
                tog(x, y + 72, w, "WH: предметы", () -> Cfg.whItems, v -> Cfg.whItems = v);
                tog(x2, y, w, "Аим", () -> Cfg.aim, v -> Cfg.aim = v);
                tog(x2, y + 24, w, "Аим только при ЛКМ", () -> Cfg.aimOnlyAttack, v -> Cfg.aimOnlyAttack = v);
                tog(x2, y + 48, w, "Аим сквозь стены", () -> Cfg.aimWalls, v -> Cfg.aimWalls = v);
                tog(x2, y + 72, w, "Цели: все существа", () -> Cfg.aimAll, v -> Cfg.aimAll = v);
                cyc(x2, y + 96, w, "Угол аима", new float[]{15, 30, 60, 120, 180}, () -> Cfg.aimFov, v -> Cfg.aimFov = v);
                cyc(x2, y + 120, w, "Дальность", new float[]{8, 16, 24, 48}, () -> Cfg.aimRange, v -> Cfg.aimRange = v);
                cyc(x2, y + 144, w, "Плавность", new float[]{0.1f, 0.2f, 0.35f, 0.6f, 1f}, () -> Cfg.aimSmooth, v -> Cfg.aimSmooth = v);
                break;
            case 2: {
                search = new TextFieldWidget(textRenderer, x, y, w, 20, new LiteralText(""));
                search.setMaxLength(32);
                search.setText(query);
                final int ry = y + 48;
                search.setChangedListener(s -> { query = s; results(x, ry, w); });
                addButton(search);
                setInitialFocus(search);
                cyc(x, y + 24, w, "Кол-во", new float[]{1, 16, 64, 256}, () -> (float) amount, v -> amount = Math.round(v));
                results(x, ry, w);
                for (int i = 0; i < KITS.length; i++) {
                    final int k = i;
                    act(x2 + (i % 2) * 131, y + (i / 2) * 24, 125, KITS[i], sp -> Features.kit(sp, k));
                }
                break;
            }
            case 3:
                act(x, y, w, "Здоровье и еда", sp -> { sp.setHealth(sp.getMaxHealth()); sp.getHungerManager().add(20, 1.0F); });
                act(x, y + 24, w, "День", sp -> sp.getServerWorld().setTimeOfDay(1000L));
                act(x, y + 48, w, "Ночь", sp -> sp.getServerWorld().setTimeOfDay(14000L));
                act(x, y + 72, w, "Ясная погода", sp -> sp.getServerWorld().setWeather(24000, 0, false, false));
                act(x2, y, w, "Режим: Креатив", sp -> sp.setGameMode(GameMode.CREATIVE));
                act(x2, y + 24, w, "Режим: Выживание", sp -> sp.setGameMode(GameMode.SURVIVAL));
                tog(x2, y + 48, w, "Яркость (fullbright)", () -> Cfg.bright, v -> Cfg.bright = v);
                break;
            case 4:
                addButton(new ButtonWidget(x, y, w, 20, new LiteralText("1. Построить карту КС"), b -> {
                    Features.srv(client, CsMode::build); client.openScreen(null);
                }));
                addButton(new ButtonWidget(x2, y, w, 20, new LiteralText("2. Старт режима КС"), b -> {
                    Features.srv(client, CsMode::start); client.openScreen(null);
                }));
                addButton(new ButtonWidget(x, y + 24, w, 20, new LiteralText("Стоп режима КС"), b ->
                        Features.srv(client, sp -> CsMode.stop(sp, "§7Режим КС остановлен", ""))));
                addButton(new ButtonWidget(x2, y + 24, w, 20, new LiteralText("Магазин (B)"), b -> {
                    if (CsMode.active) client.openScreen(new CsBuyScreen());
                }));
                break;
            case 5:
                perf(x, y, w, "Макс. FPS", 0);
                perf(x, y + 24, w, "Баланс", 1);
                perf(x, y + 48, w, "Вернуть мои настройки", 2);
                break;
            default:
        }
    }

    // ---------- helpers ----------
    private Text lbl(String n, boolean on) { return new LiteralText(n + ": " + (on ? "§aВКЛ" : "§cВЫКЛ")); }

    private void tog(int x, int y, int w, String n, BooleanSupplier g, Consumer<Boolean> s) {
        addButton(new ButtonWidget(x, y, w, 20, lbl(n, g.getAsBoolean()), b -> {
            s.accept(!g.getAsBoolean());
            b.setMessage(lbl(n, g.getAsBoolean()));
        }));
    }

    private static String fmt(float v) { return String.valueOf(Math.round(v * 100) / 100f); }

    private void cyc(int x, int y, int w, String n, float[] vals, Supplier<Float> g, Consumer<Float> s) {
        addButton(new ButtonWidget(x, y, w, 20, new LiteralText(n + ": " + fmt(g.get())), b -> {
            float cur = g.get();
            int idx = 0;
            for (int k = 0; k < vals.length; k++) if (Math.abs(vals[k] - cur) < 1e-4) idx = k;
            s.accept(vals[(idx + 1) % vals.length]);
            b.setMessage(new LiteralText(n + ": " + fmt(g.get())));
        }));
    }

    private void act(int x, int y, int w, String n, Consumer<ServerPlayerEntity> a) {
        addButton(new ButtonWidget(x, y, w, 20, new LiteralText(n), b -> Features.srv(client, a)));
    }

    private void perf(int x, int y, int w, String n, int mode) {
        addButton(new ButtonWidget(x, y, w, 20, new LiteralText(n), b -> Perf.apply(client, mode)));
    }

    private void results(int x, int y, int w) {
        buttons.removeAll(res);
        children().removeAll(res);
        res.clear();
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return;
        int n = 0;
        for (Item it : Registry.ITEM) {
            if (it == Items.AIR) continue;
            String name = it.getName().getString();
            if (!name.toLowerCase(Locale.ROOT).contains(q) && !Registry.ITEM.getId(it).getPath().contains(q)) continue;
            ButtonWidget b = new ButtonWidget(x, y + n * 21, w, 20, new LiteralText(name),
                    bt -> Features.srv(client, sp -> Features.give(sp, it, amount)));
            res.add(b);
            addButton(b);
            if (++n >= 8) break;
        }
    }

    @Override
    public void tick() { if (search != null) search.tick(); }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (CheatMenuClient.openKey.matchesKey(keyCode, scanCode)) { onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(MatrixStack m, int mx, int my, float d) {
        renderBackground(m);
        drawCenteredText(m, textRenderer, "§lЧИТ-МЕНЮ §r§7— только одиночная игра", width / 2, 10, 0xFFFFFF);
        int x = 118, y = 28;
        if (!ok() && tab != 5 && tab != 6) {
            drawStringWithShadow(m, textRenderer, "§cНедоступно: ты на сервере / в LAN. Читы отключены.", x, y, 0xFFFFFF);
        } else if (tab == 4) {
            String[] l = {"§7Карта: 3 линии (A-лонг, мид, B), спавны T и CT.",
                    "§7Ты за CT, враги — T-боты (пиллагеры с арбалетами).",
                    "§7Закупка 15 сек — клавиша B. Деньги за убийства и победы.",
                    "§7Мирная сложность включится в Нормальную сама."};
            for (int i = 0; i < l.length; i++) drawStringWithShadow(m, textRenderer, l[i], x, y + 56 + i * 12, 0xFFFFFF);
        } else if (tab == 5) {
            String[] l = {"§7Макс. FPS: дальность 8, мин. частицы, быстрая графика,",
                    "§7без облаков и AO, vsync выкл. «Вернуть» — откат.",
                    "",
                    "§eДля ещё большего буста положи в mods:",
                    "§fSodium, Lithium, Phosphor/Starlight, FerriteCore, EntityCulling"};
            for (int i = 0; i < l.length; i++) drawStringWithShadow(m, textRenderer, l[i], x, y + 76 + i * 12, 0xFFFFFF);
        } else if (tab == 6) {
            for (int i = 0; i < HELP.length; i++) drawStringWithShadow(m, textRenderer, HELP[i], x, y + i * 12, 0xFFFFFF);
        }
        super.render(m, mx, my, d);
    }
}
