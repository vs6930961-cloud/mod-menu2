package ru.cheatmenu;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

public class CsBuyScreen extends Screen {
    public CsBuyScreen() { super(new LiteralText("Магазин КС")); }

    @Override
    protected void init() {
        int x = width / 2 - 100, y = height / 2 - 80;
        for (int i = 0; i < CsMode.SHOP.length; i++) {
            final int id = i;
            addButton(new ButtonWidget(x, y + i * 24, 200, 20,
                    new LiteralText(CsMode.SHOP[i] + "  §a$" + CsMode.PRICE[i]),
                    b -> CsMode.buy(client, id)));
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(MatrixStack m, int mx, int my, float d) {
        renderBackground(m);
        drawCenteredText(m, textRenderer, "§lМАГАЗИН КС  §a$" + CsMode.money
                + (CsMode.phase != 1 ? "  §c(закупка закрыта)" : ""), width / 2, height / 2 - 100, 0xFFFFFF);
        super.render(m, mx, my, d);
    }
}
