package ru.cheatmenu;

public final class Cfg {
    public static boolean fly, wh, whPlayers = true, whMobs = true, whItems,
            aim, aimWalls, aimOnlyAttack = true, aimAll,
            bhop, strafe, bright;
    public static float flySpeed = 2f, aimFov = 60f, aimRange = 24f, aimSmooth = 0.35f,
            strafePower = 1f, maxSpeed = 0.7f;

    static void disableAll() { fly = wh = aim = bhop = strafe = bright = false; }
    static boolean anyOn() { return fly || wh || aim || bhop || strafe || bright; }
}
