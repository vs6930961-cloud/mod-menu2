package ru.cheatmenu;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;

public final class CsMode {
    public static volatile boolean active;
    public static volatile int phase, money;
    static final int IDLE = 0, BUY = 1, LIVE = 2, OVER = 3;
    static int round, ct, tr, timer, kills, ox, oy, oz;
    static boolean mapBuilt, died, oldKeep, oldSpawn;
    static UUID pid;
    static final Random R = new Random();
    static final List<UUID> bots = new ArrayList<UUID>();
    static final Set<UUID> counted = new HashSet<UUID>();

    public static final String[] SHOP = {"AK-47 (арбалет)", "AWP (лук)", "Кевлар", "Шлем", "Аптечка (зол. яблоко)", "Патроны x32", "Щит"};
    public static final int[] PRICE = {2700, 4750, 650, 350, 400, 100, 300};

    // ---------- Карта ----------
    static void fill(ServerWorld w, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    w.setBlockState(m.set(ox + x, oy + y, oz + z), s, 18);
    }

    static void build(ServerPlayerEntity sp) {
        ServerWorld w = sp.getServerWorld();
        BlockPos o = sp.getBlockPos().add(6, 0, -20);
        ox = o.getX(); oy = o.getY(); oz = o.getZ();
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState base = Blocks.SANDSTONE.getDefaultState();
        BlockState sand = Blocks.SMOOTH_SANDSTONE.getDefaultState();
        BlockState wall = Blocks.CUT_SANDSTONE.getDefaultState();
        BlockState crate = Blocks.OAK_PLANKS.getDefaultState();

        fill(w, 0, 0, 0, 63, 11, 39, air);                 // очистка
        fill(w, 0, -5, 0, 63, -2, 39, base);               // фундамент
        fill(w, 0, -1, 0, 63, -1, 39, sand);               // пол
        fill(w, 0, 0, 0, 63, 8, 0, wall);                  // внешние стены
        fill(w, 0, 0, 39, 63, 8, 39, wall);
        fill(w, 0, 0, 0, 0, 8, 39, wall);
        fill(w, 63, 0, 0, 63, 8, 39, wall);
        fill(w, 1, -1, 14, 10, -1, 25, Blocks.ORANGE_TERRACOTTA.getDefaultState());   // T-спавн
        fill(w, 53, -1, 14, 62, -1, 25, Blocks.BLUE_TERRACOTTA.getDefaultState());    // CT-спавн
        fill(w, 11, 0, 12, 52, 5, 13, wall); fill(w, 30, 0, 12, 33, 5, 13, air);     // разделитель юг/мид
        fill(w, 11, 0, 26, 52, 5, 27, wall); fill(w, 30, 0, 26, 33, 5, 27, air);     // разделитель мид/север
        fill(w, 42, -1, 2, 52, -1, 10, Blocks.RED_TERRACOTTA.getDefaultState());      // точка A
        fill(w, 42, -1, 29, 52, -1, 37, Blocks.YELLOW_TERRACOTTA.getDefaultState());  // точка B
        int[][] boxes = {{18, 4}, {24, 8}, {36, 3}, {44, 5}, {48, 8}, {18, 31}, {25, 35}, {37, 34},
                {45, 31}, {50, 36}, {24, 17}, {34, 20}, {44, 22}, {15, 22}};
        for (int[] b : boxes) fill(w, b[0], 0, b[1], b[0] + 1, 1, b[1] + 1, crate);  // ящики

        mapBuilt = true;
        sp.teleport(w, ox + 58.5, oy, oz + 20.5, 90F, 0F);
        sp.sendMessage(new LiteralText("§aКарта КС готова. T слева (оранж.), A — красный, B — жёлтый."), false);
    }

    // ---------- Режим ----------
    static void start(ServerPlayerEntity sp) {
        if (active) return;
        MinecraftServer s = sp.server;
        if (!mapBuilt) build(sp);
        ServerWorld w = sp.getServerWorld();
        if (w.getDifficulty() == Difficulty.PEACEFUL) s.setDifficulty(Difficulty.NORMAL, true);
        GameRules g = s.getGameRules();
        oldKeep = g.getBoolean(GameRules.KEEP_INVENTORY);
        oldSpawn = g.getBoolean(GameRules.DO_MOB_SPAWNING);
        g.get(GameRules.KEEP_INVENTORY).set(true, s);
        g.get(GameRules.DO_MOB_SPAWNING).set(false, s);
        pid = sp.getUuid();
        round = 0; ct = 0; tr = 0; kills = 0; money = 800; died = true;
        active = true;
        nextRound(sp, w);
    }

    static ItemStack named(net.minecraft.item.Item i, String n) {
        ItemStack s = new ItemStack(i);
        s.setCustomName(new LiteralText(n));
        return s;
    }

    static void kit(ServerPlayerEntity sp) {
        Features.give(sp, named(Items.IRON_SWORD, "§7Нож"));
        ItemStack pistol = named(Items.CROSSBOW, "§eUSP-S");
        pistol.addEnchantment(Enchantments.QUICK_CHARGE, 1);
        Features.give(sp, pistol);
        Features.give(sp, Items.ARROW, 32);
    }

    static void nextRound(ServerPlayerEntity sp, ServerWorld w) {
        round++;
        phase = BUY; timer = 15 * 20;
        bots.clear(); counted.clear();
        if (died) { sp.inventory.clear(); kit(sp); died = false; }
        sp.setHealth(sp.getMaxHealth());
        sp.getHungerManager().add(20, 1.0F);
        sp.teleport(w, ox + 58.5, oy, oz + 20.5, 90F, 0F);
        int n = Math.min(2 + round, 8);
        for (int i = 0; i < n; i++) {
            PillagerEntity b = EntityType.PILLAGER.create(w);
            if (b == null) continue;
            b.refreshPositionAndAngles(ox + 3 + R.nextInt(7) + 0.5, oy, oz + 15 + R.nextInt(10) + 0.5, R.nextFloat() * 360F, 0F);
            b.initialize(w, w.getLocalDifficulty(b.getBlockPos()), SpawnReason.COMMAND, null, null);
            b.setCustomName(new LiteralText("§cT-бот"));
            b.setCustomNameVisible(true);
            b.setPersistent();
            b.setAiDisabled(true);
            w.spawnEntity(b);
            bots.add(b.getUuid());
        }
        title(sp, "§6Раунд " + round, "§7Закупка 15 сек — жми B");
    }

    static void end(ServerPlayerEntity sp, ServerWorld w, boolean win, String msg) {
        if (win) { ct++; money = Math.min(16000, money + 3250); }
        else { tr++; money = Math.min(16000, money + 1400); died = true; }
        removeBots(w);
        phase = OVER; timer = 5 * 20;
        title(sp, win ? "§bCT победили" : "§cT победили", "§7" + msg + "  Счёт " + ct + ":" + tr);
    }

    static void removeBots(ServerWorld w) {
        for (UUID u : bots) {
            Entity e = w.getEntity(u);
            if (e != null && e.isAlive()) e.remove();
        }
        bots.clear();
    }

    static void stop(ServerPlayerEntity sp, String a, String b) {
        if (!active) return;
        removeBots(sp.getServerWorld());
        restoreRules(sp.server);
        active = false; phase = IDLE;
        title(sp, a, b);
    }

    static void restoreRules(MinecraftServer s) {
        GameRules g = s.getGameRules();
        g.get(GameRules.KEEP_INVENTORY).set(oldKeep, s);
        g.get(GameRules.DO_MOB_SPAWNING).set(oldSpawn, s);
    }

    public static void onStop(MinecraftServer s) {
        if (active) restoreRules(s);
        active = false; phase = IDLE; mapBuilt = false;
        bots.clear(); counted.clear();
    }

    static void title(ServerPlayerEntity sp, String a, String b) {
        sp.networkHandler.sendPacket(new TitleS2CPacket(TitleS2CPacket.Action.TITLE, new LiteralText(a)));
        sp.networkHandler.sendPacket(new TitleS2CPacket(TitleS2CPacket.Action.SUBTITLE, new LiteralText(b)));
    }

    // ---------- Магазин ----------
    public static void buy(MinecraftClient mc, int id) {
        Features.srv(mc, sp -> {
            if (!active || phase != BUY) { sp.sendMessage(new LiteralText("§cЗакупка закрыта"), true); return; }
            if (money < PRICE[id]) { sp.sendMessage(new LiteralText("§cНе хватает денег"), true); return; }
            money -= PRICE[id];
            ItemStack s;
            switch (id) {
                case 0:
                    s = named(Items.CROSSBOW, "§6AK-47");
                    s.addEnchantment(Enchantments.QUICK_CHARGE, 3);
                    s.addEnchantment(Enchantments.PIERCING, 2);
                    Features.give(sp, s); break;
                case 1:
                    s = named(Items.BOW, "§6AWP");
                    s.addEnchantment(Enchantments.POWER, 5);
                    s.addEnchantment(Enchantments.PUNCH, 2);
                    Features.give(sp, s); break;
                case 2: sp.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE)); break;
                case 3: sp.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET)); break;
                case 4: Features.give(sp, Items.GOLDEN_APPLE, 1); break;
                case 5: Features.give(sp, Items.ARROW, 32); break;
                default: Features.give(sp, Items.SHIELD, 1);
            }
        });
    }

    // ---------- Тик сервера ----------
    public static void tick(MinecraftServer s) {
        if (!active) return;
        ServerPlayerEntity sp = s.getPlayerManager().getPlayer(pid);
        if (sp == null) return;
        ServerWorld w = sp.getServerWorld();
        if (timer > 0) timer--;

        int alive = 0;
        if (phase == BUY || phase == LIVE) {
            for (UUID u : bots) {
                Entity e = w.getEntity(u);
                if (e != null && e.isAlive()) alive++;
                else if (counted.add(u)) { money = Math.min(16000, money + 300); kills++; }
            }
        }

        if (phase == BUY && timer == 0) {
            phase = LIVE; timer = 120 * 20;
            for (UUID u : bots) {
                Entity e = w.getEntity(u);
                if (e instanceof MobEntity) ((MobEntity) e).setAiDisabled(false);
            }
            title(sp, "§cВ бой!", "§7Убей всех T-ботов");
        } else if (phase == LIVE) {
            if (!sp.isAlive()) end(sp, w, false, "Ты погиб.");
            else if (alive == 0) end(sp, w, true, "Все боты убиты.");
            else if (timer == 0) end(sp, w, true, "Время вышло.");
        } else if (phase == OVER && timer == 0 && sp.isAlive()) {
            if (ct >= 8 || tr >= 8) stop(sp, ct >= 8 ? "§bМатч выигран!" : "§cМатч проигран", "Счёт " + ct + ":" + tr);
            else nextRound(sp, w);
        }

        if (active && (phase == BUY || phase == LIVE) && s.getTicks() % 10 == 0) {
            sp.sendMessage(new LiteralText("§6Р" + round + " §bCT " + ct + "§f:§c" + tr + " T §f| §a$" + money
                    + " §f| Боты: §c" + alive + " §f| " + (phase == BUY ? "§eзакупка " : "§f") + (timer / 20) + "с"), true);
        }
    }
}
