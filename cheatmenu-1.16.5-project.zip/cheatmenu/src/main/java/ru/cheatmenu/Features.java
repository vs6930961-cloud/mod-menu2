package ru.cheatmenu;

import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Features {
    private static boolean flyOn, whOn, brightOn, hopped, wasGround;
    private static double held, oldGamma;
    private static float lastYaw;

    /** Читы разрешены ТОЛЬКО в одиночке (LAN и серверы — нет). */
    static boolean allowed(MinecraftClient mc) {
        return mc.isInSingleplayer() && mc.getServer() != null;
    }

    /** Выполнить действие над игроком на потоке встроенного сервера (без команд). */
    static void srv(MinecraftClient mc, Consumer<ServerPlayerEntity> c) {
        MinecraftServer s = mc.getServer();
        if (s == null || mc.player == null) return;
        UUID id = mc.player.getUuid();
        s.execute(() -> {
            ServerPlayerEntity sp = s.getPlayerManager().getPlayer(id);
            if (sp != null) c.accept(sp);
        });
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { flyOn = false; whOn = false; held = 0; hopped = false; return; }
        if (!allowed(mc) && Cfg.anyOn()) Cfg.disableAll();   // на сервере всё просто выключается
        fly(mc, p);
        wh(mc, p);
        bright(mc);
        if (Cfg.aim) aim(mc, p);
        move(mc, p);
    }

    // ---------- Полёт ----------
    private static void fly(MinecraftClient mc, ClientPlayerEntity p) {
        if (Cfg.fly) {
            if (!p.abilities.allowFlying) {
                p.abilities.allowFlying = true;
                srv(mc, sp -> { sp.abilities.allowFlying = true; sp.sendAbilitiesUpdate(); });
            }
            flyOn = true;
            p.abilities.setFlySpeed(0.05F * Cfg.flySpeed);
        } else if (flyOn) {
            flyOn = false;
            p.abilities.setFlySpeed(0.05F);
            if (!p.isCreative() && !p.isSpectator()) { p.abilities.allowFlying = false; p.abilities.flying = false; }
            srv(mc, sp -> {
                if (!sp.isCreative() && !sp.isSpectator()) {
                    sp.abilities.allowFlying = false; sp.abilities.flying = false; sp.sendAbilitiesUpdate();
                }
            });
        }
    }

    // ---------- WH (подсветка сквозь стены) ----------
    private static void wh(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Cfg.wh && !whOn) return;
        whOn = Cfg.wh;
        for (Entity e : mc.world.getEntities()) {
            if (e == p) continue;
            boolean want = Cfg.wh && (
                    (e instanceof PlayerEntity && Cfg.whPlayers)
                    || (e instanceof LivingEntity && !(e instanceof PlayerEntity) && Cfg.whMobs)
                    || (e instanceof ItemEntity && Cfg.whItems));
            if (e.isGlowing() != want) e.setGlowing(want);
        }
    }

    // ---------- Яркость ----------
    private static void bright(MinecraftClient mc) {
        if (Cfg.bright) {
            if (!brightOn) { oldGamma = mc.options.gamma; brightOn = true; }
            mc.options.gamma = 16.0D;
        } else if (brightOn) {
            mc.options.gamma = oldGamma; brightOn = false;
        }
    }

    // ---------- Аим ----------
    private static void aim(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        if (Cfg.aimOnlyAttack && !mc.options.keyAttack.isPressed()) return;
        Vec3d eye = p.getCameraPosVec(1.0F);
        double best = Cfg.aimFov;
        float ty = 0, tp = 0;
        boolean found = false;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity) || !e.isAlive() || e.isSpectator() || e instanceof ArmorStandEntity) continue;
            if (!Cfg.aimAll && !(e instanceof Monster)) continue;
            if (p.distanceTo(e) > Cfg.aimRange) continue;
            if (!Cfg.aimWalls && !p.canSee(e)) continue;
            double dx = e.getX() - eye.x, dy = e.getEyeY() - eye.y, dz = e.getZ() - eye.z;
            float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232D) - 90F;
            float pitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29577951308232D);
            double ang = Math.hypot(MathHelper.wrapDegrees(yaw - p.yaw), pitch - p.pitch);
            if (ang < best) { best = ang; ty = yaw; tp = pitch; found = true; }
        }
        if (!found) return;
        p.yaw += MathHelper.wrapDegrees(ty - p.yaw) * Cfg.aimSmooth;
        p.pitch = MathHelper.clamp(p.pitch + (tp - p.pitch) * Cfg.aimSmooth, -90F, 90F);
    }

    // ---------- Банихоп + стрейфы ----------
    private static void move(MinecraftClient mc, ClientPlayerEntity p) {
        boolean ground = p.isOnGround();
        float dyaw = Math.abs(MathHelper.wrapDegrees(p.yaw - lastYaw));
        lastYaw = p.yaw;
        if (!(Cfg.bhop || Cfg.strafe) || mc.currentScreen != null || p.abilities.flying || p.isFallFlying()
                || p.hasVehicle() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) {
            held = 0; hopped = false; wasGround = ground; return;
        }
        Vec3d v = p.getVelocity();
        double hs = Math.hypot(v.x, v.z);
        float f = p.input.movementForward, s = p.input.movementSideways;
        boolean moving = f != 0 || s != 0;
        double wx = 0, wz = 0;
        if (moving) {
            double l = Math.sqrt(f * f + s * s);
            double sn = Math.sin(Math.toRadians(p.yaw)), cs = Math.cos(Math.toRadians(p.yaw));
            wx = (s * cs - f * sn) / l;
            wz = (f * cs + s * sn) / l;
        }

        if (ground) {
            if (Cfg.bhop && mc.options.keyJump.isPressed() && moving) {
                double t = Math.min(Cfg.maxSpeed, Math.max(0.25, Math.max(held, hs + (p.isSprinting() ? 0.2 : 0.0))));
                double dx = hs > 0.01 ? v.x / hs : wx, dz = hs > 0.01 ? v.z / hs : wz;
                double jv = 0.42 + (p.hasStatusEffect(StatusEffects.JUMP_BOOST)
                        ? 0.1 * (p.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1) : 0);
                p.setVelocity(dx * t, jv, dz * t);
                held = t; hopped = true;
            } else { held = hs; hopped = false; }
            wasGround = true;
            return;
        }

        if (hopped || Cfg.strafe) {
            if (!hopped && wasGround) held = Math.max(held, hs);          // обычный прыжок
            if (p.horizontalCollision) { held = hs; hopped = false; wasGround = false; return; }
            if (moving) {
                double hx = v.x, hz = v.z;
                if (Cfg.strafe) {
                    hx += wx * 0.03 * Cfg.strafePower;                     // воздушный контроль
                    hz += wz * 0.03 * Cfg.strafePower;
                    if (dyaw > 0.3F && s != 0)                              // набор скорости поворотом мыши
                        held = Math.min(Cfg.maxSpeed, held + Math.min(dyaw, 10F) / 10F * 0.006 * Cfg.strafePower);
                }
                double l = Math.hypot(hx, hz);
                if (l > 1e-4) { double k = held / l; p.setVelocity(hx * k, v.y, hz * k); }
            }
            hopped = false;
        }
        wasGround = false;
    }

    // ---------- Выдача предметов (без команд) ----------
    static void give(ServerPlayerEntity sp, ItemStack st) {
        if (!sp.inventory.insertStack(st)) sp.dropItem(st, false);
    }

    static void give(ServerPlayerEntity sp, Item it, int total) {
        int max = it.getMaxCount();
        while (total > 0) {
            int c = Math.min(max, total);
            total -= c;
            give(sp, new ItemStack(it, c));
        }
    }

    static void gear(ServerPlayerEntity sp, boolean neth) {
        Item[] a = neth
                ? new Item[]{Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
                        Items.NETHERITE_SWORD, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_SHOVEL}
                : new Item[]{Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
                        Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL};
        for (int i = 0; i < a.length; i++) {
            ItemStack st = new ItemStack(a[i]);
            if (i < 4) st.addEnchantment(Enchantments.PROTECTION, 4);
            else if (i == 4) st.addEnchantment(Enchantments.SHARPNESS, 5);
            else st.addEnchantment(Enchantments.EFFICIENCY, 5);
            st.addEnchantment(Enchantments.UNBREAKING, 3);
            give(sp, st);
        }
    }

    static void kit(ServerPlayerEntity sp, int i) {
        switch (i) {
            case 0: give(sp, Items.DIAMOND, 64); break;
            case 1: give(sp, Items.NETHERITE_INGOT, 16); break;
            case 2: give(sp, Items.GOLDEN_APPLE, 16); break;
            case 3: give(sp, Items.ENCHANTED_GOLDEN_APPLE, 8); break;
            case 4: give(sp, Items.ENDER_PEARL, 16); break;
            case 5: give(sp, Items.COOKED_BEEF, 64); break;
            case 6: give(sp, Items.COBBLESTONE, 64); break;
            case 7: give(sp, Items.TNT, 32); break;
            case 8: give(sp, Items.ELYTRA, 1); give(sp, Items.FIREWORK_ROCKET, 64); break;
            case 9: gear(sp, false); break;
            case 10: gear(sp, true); break;
            default: sp.addExperienceLevels(30);
        }
    }
}
