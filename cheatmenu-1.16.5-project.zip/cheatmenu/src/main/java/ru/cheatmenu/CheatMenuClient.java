package ru.cheatmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CheatMenuClient implements ClientModInitializer {
    public static KeyBinding openKey, buyKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cheatmenu.open",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.cheatmenu"));
        buyKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.cheatmenu.buy",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.cheatmenu"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Features.tick(mc);
            while (openKey.wasPressed()) if (mc.currentScreen == null) mc.openScreen(new MenuScreen());
            while (buyKey.wasPressed()) if (mc.currentScreen == null && CsMode.active) mc.openScreen(new CsBuyScreen());
        });
        ServerTickEvents.END_SERVER_TICK.register(CsMode::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(CsMode::onStop);
    }
}
