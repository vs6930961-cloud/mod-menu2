package ru.cheatmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.AoOption;
import net.minecraft.client.options.CloudRenderMode;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.options.GraphicsMode;
import net.minecraft.client.options.ParticlesOption;

public final class Perf {
    private static boolean saved, vs;
    private static int vd, fps, blend;
    private static float eds;
    private static ParticlesOption pa;
    private static GraphicsMode gm;
    private static CloudRenderMode cl;
    private static AoOption ao;

    /** 0 = макс. FPS, 1 = баланс, 2 = вернуть как было */
    public static void apply(MinecraftClient mc, int mode) {
        GameOptions o = mc.options;
        if (mode == 2) {
            if (!saved) return;
            o.viewDistance = vd; o.particles = pa; o.graphicsMode = gm; o.cloudRenderMode = cl; o.ao = ao;
            o.entityDistanceScaling = eds; o.biomeBlendRadius = blend; o.maxFps = fps; o.enableVsync = vs;
            saved = false;
        } else {
            if (!saved) {
                vd = o.viewDistance; pa = o.particles; gm = o.graphicsMode; cl = o.cloudRenderMode; ao = o.ao;
                eds = o.entityDistanceScaling; blend = o.biomeBlendRadius; fps = o.maxFps; vs = o.enableVsync;
                saved = true;
            }
            boolean max = mode == 0;
            o.viewDistance = max ? 8 : 12;
            o.particles = max ? ParticlesOption.MINIMAL : ParticlesOption.DECREASED;
            o.graphicsMode = GraphicsMode.FAST;
            o.cloudRenderMode = max ? CloudRenderMode.OFF : CloudRenderMode.FAST;
            o.ao = max ? AoOption.OFF : AoOption.MIN;
            o.entityDistanceScaling = max ? 0.5F : 0.75F;
            o.biomeBlendRadius = max ? 0 : 2;
            o.maxFps = 260;
            o.enableVsync = false;
        }
        mc.getWindow().setVsync(o.enableVsync);
        o.write();
        if (mc.world != null && mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
