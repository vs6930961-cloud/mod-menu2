@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Install JDK 17 and Gradle 7.3.3 first, then run this again.
  pause
  exit /b 1
)
gradle wrapper --gradle-version 7.3.3
call gradlew.bat build
echo.
echo Done: build\libs\cheatmenu-1.0.0.jar
pause
